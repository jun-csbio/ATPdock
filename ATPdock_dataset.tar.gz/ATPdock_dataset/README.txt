ATPDOCK_DATASET

FILE NAMING FORMAT

The file name format of the native ATP pose files consists of 16 characters:
Characters	
    1-4: Receptor PDB Code*
    5-9: '_ATP_'
    10: the chain of receptor
    11: '_'
    12: the index of pocket of receptor
    13-16: '.pdb' (file extension)

*Bindingsite.txt contains binding site information of all receptors. Every row represents a binding pocket. The character before the first space represents the receptor PDB code, and the character after it represents its binding pocket information.
Binding site information consists of name and index of binding residues. If the number of receptor binding pockets is more than one, there is an index of pockets behind the receptor PDB code, which is enclosed in parentheses.